import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../../widgets/menuPrincipal.dart';
import '../../widgets/temporizador.dart';

class UsuarioEntrenamiento extends StatelessWidget {
  static const routeName = '/usuarioEntrenamiento';
  final Timestamp fechaElegida;

  const UsuarioEntrenamiento(this.fechaElegida);

  @override
  Widget build(BuildContext context) {
    print(fechaElegida);
    return Scaffold(
      appBar: MenuPrincipal(context),
      body: Center(
        child: Temporizador(
          fechaElegida: fechaElegida,
        ),
      ),
    );
  }
}
