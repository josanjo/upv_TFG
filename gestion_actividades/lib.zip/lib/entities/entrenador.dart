class Entrenador {
  final String nombre;
  final String apellidos;
  final String edad;
  final String email;
  final String password;

  Entrenador(this.nombre, this.apellidos, this.edad, this.email, this.password);
}
