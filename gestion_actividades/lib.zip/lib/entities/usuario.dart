class Usuario {
  final String nombre;
  final String apellidos;
  final String edad;
  final String peso;
  final String altura;
  //final String entrenador;
  final String email;
  final String password;

  Usuario(
      this.nombre,
      this.apellidos,
      this.edad,
      this.email,
      this.password,
      this.peso,
      //,this.entrenador
      this.altura);
}
