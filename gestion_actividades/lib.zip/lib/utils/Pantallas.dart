// ignore_for_file: file_names
// SE AÑADE EN TODOS LOS FICHEROS
export '../screens/Administrador/adminScreen.dart';
export '../screens/Administrador/crearUsuarios.dart';
export '../screens/Administrador/crearEntrenador.dart';
export '../screens/Administrador/mensajes.dart';
export '../screens/Administrador/listado.dart';

export '../screens/Usuarios/usuarioScreen.dart';
export '../screens/Usuarios/usuarioEntrenamiento.dart';
export '/screens/Usuarios/usuarioScreen.dart';

export '../screens/Entrenador/entrenadorScreen.dart';
export '../screens/Entrenador/listadoUsuarios.dart';
export '../screens/Entrenador/formularioEntrenamientos.dart';
export '../screens/Entrenador/enviarMensaje.dart';

export '../screens/loginScreen.dart';
export '../screens/errorScreen.dart';
